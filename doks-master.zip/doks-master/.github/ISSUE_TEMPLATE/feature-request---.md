---
name: "Feature request \U0001F680"
about: Suggest an idea for Doks

---

## Summary

Brief explanation of the feature.

### Basic example

Include a basic example or links here.

### Motivation

Why are we doing this? What use cases does it support? What is the expected outcome?
